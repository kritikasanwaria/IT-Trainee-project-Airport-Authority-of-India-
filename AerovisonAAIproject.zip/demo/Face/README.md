# 3D-Assisted Face Recognition (Laptop Webcam)

Uses:
- **face_recognition** (dlib) — 128-d embedding for identity matching
- **MediaPipe Face Mesh** — 468 3D landmarks (x, y, z) for geometric verification / basic liveness check

## Setup

```bash
pip install face_recognition opencv-python mediapipe numpy
```

**Note:** `face_recognition` depends on `dlib`, which needs a C++ compiler and CMake.
- **Windows:** install "Desktop development with C++" via Visual Studio Build Tools, and CMake, before `pip install`.
- **Mac:** `brew install cmake` first.
- **Linux:** `sudo apt install cmake build-essential` first.

If dlib install trouble persists, let me know your OS and I can give a more specific fix.

## Usage

### 1. Enroll a person
```bash
python enroll.py --name "Your Name"
```
Look at the camera. It automatically captures 5 clear samples (move your head slightly between captures for better averaging), then saves to `face_data.pkl`.

You can enroll multiple people — just run again with different `--name` values; entries are added to the same database file.

### 2. Verify a person
```bash
python verify.py
```
Opens the webcam and continuously shows whether the live face matches anyone in `face_data.pkl`, with the matched name and a distance score. Press `q` to quit.

## Tuning

In `verify.py`:
- `EMBEDDING_THRESHOLD` (default 0.5) — lower = stricter identity match, fewer false accepts but more false rejects.
- `LANDMARK_THRESHOLD` (default 0.06) — lower = stricter geometric/liveness match.

If you get false rejects of yourself, raise these slightly. If strangers are matching, lower them.

## Limitations to know

- This uses **monocular pseudo-3D** (MediaPipe estimates depth from a single 2D image) — not measured depth. It adds a helpful geometric consistency check but is not as spoof-proof as a true depth camera (e.g. iPhone Face ID / Kinect).
- Lighting and camera angle affect accuracy — enroll in similar lighting to where you'll verify.
- This is a learning/prototype-grade system, not hardened for production security use (e.g. banking, building access) without further work (anti-spoofing/liveness challenges, encrypted storage, etc.).
