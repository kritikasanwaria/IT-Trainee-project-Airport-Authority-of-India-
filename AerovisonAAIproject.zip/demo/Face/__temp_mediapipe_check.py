import mediapipe as mp
print(mp.__file__)
print('has_solutions=', hasattr(mp, 'solutions'))
print([a for a in dir(mp) if 'solution' in a.lower() or 'face' in a.lower()][:50])
