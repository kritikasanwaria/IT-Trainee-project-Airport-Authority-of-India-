"""
enroll.py
---------
Captures a person's face using the laptop webcam and stores:
  1. A 128-d face embedding (face_recognition / dlib) used for identity matching
  2. 468 3D face-mesh landmarks (MediaPipe) used as a geometric signature
     and for basic liveness checks

Data is stored in face_data.pkl (a simple local database).

Usage:
    python enroll.py --name "John Doe"
"""

import argparse
import pickle
import os
import time

import cv2
import numpy as np
import face_recognition

from face3d_utils import create_face_landmarker, get_landmarks_3d

DB_PATH = "face_data.pkl"
NUM_SAMPLES = 5          # number of good frames to average per enrollment
MIN_FACE_SIZE = 100      # min pixel width of detected face to accept a frame


def load_db():
    if os.path.exists(DB_PATH):
        with open(DB_PATH, "rb") as f:
            return pickle.load(f)
    return {}


def save_db(db):
    with open(DB_PATH, "wb") as f:
        pickle.dump(db, f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True, help="Name/ID of the person to enroll")
    args = parser.parse_args()

    db = load_db()

    landmarker = create_face_landmarker()
    frame_timestamp_ms = 0

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: could not open webcam.")
        return

    print(f"Enrolling '{args.name}'. Look at the camera.")
    print("Press 'q' to quit early. Capturing automatically when a clear face is found...")

    embeddings = []
    landmark_sets = []
    collected = 0

    while collected < NUM_SAMPLES:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb = np.ascontiguousarray(rgb)
        frame_timestamp_ms += 33  # approx frame interval, must be increasing

        # Face location + embedding (face_recognition works on RGB)
        face_locations = face_recognition.face_locations(rgb, model="hog")

        display = frame.copy()

        if face_locations:
            top, right, bottom, left = face_locations[0]
            face_width = right - left

            cv2.rectangle(display, (left, top), (right, bottom), (0, 255, 0), 2)

            if face_width >= MIN_FACE_SIZE:
                encodings = face_recognition.face_encodings(rgb, [face_locations[0]])
                landmarks_3d = get_landmarks_3d(landmarker, rgb, frame_timestamp_ms)

                if encodings and landmarks_3d is not None:
                    embeddings.append(encodings[0])
                    landmark_sets.append(landmarks_3d)
                    collected += 1
                    print(f"Captured sample {collected}/{NUM_SAMPLES}")
                    time.sleep(0.5)  # slight pause between captures for pose variation

        cv2.putText(display, f"Samples: {collected}/{NUM_SAMPLES}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.imshow("Enrollment - press q to quit", display)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    landmarker.close()

    if collected == 0:
        print("No samples captured. Enrollment failed.")
        return

    avg_embedding = np.mean(embeddings, axis=0)
    avg_landmarks = np.mean(landmark_sets, axis=0)

    db[args.name] = {
        "embedding": avg_embedding,
        "landmarks_3d": avg_landmarks,
        "num_samples": collected,
    }
    save_db(db)

    print(f"\nEnrollment complete for '{args.name}' using {collected} sample(s).")
    print(f"Data saved to {DB_PATH}")


if __name__ == "__main__":
    main()
