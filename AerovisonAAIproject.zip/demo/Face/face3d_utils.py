"""
face3d_utils.py
----------------
Shared helper for extracting 3D face landmarks using the modern
MediaPipe Tasks API (mediapipe.tasks.python.vision.FaceLandmarker),
since newer mediapipe versions no longer ship the old
`mediapipe.solutions.face_mesh` API.

Handles auto-downloading the required model file on first use.
"""

import os
import urllib.request

import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision as mp_vision

MODEL_PATH = "face_landmarker.task"
MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
    "face_landmarker/float16/latest/face_landmarker.task"
)


def ensure_model():
    """Download the FaceLandmarker model file if it isn't present locally."""
    if not os.path.exists(MODEL_PATH):
        print("Downloading face landmark model (one-time, ~4MB)...")
        urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
        print("Model downloaded.")


def create_face_landmarker():
    """Create and return a FaceLandmarker detector instance."""
    ensure_model()
    base_options = mp_tasks.BaseOptions(model_asset_path=MODEL_PATH)
    options = mp_vision.FaceLandmarkerOptions(
        base_options=base_options,
        num_faces=1,
        min_face_detection_confidence=0.6,
        min_face_presence_confidence=0.6,
        min_tracking_confidence=0.6,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=False,
        running_mode=mp_vision.RunningMode.VIDEO,
    )
    return mp_vision.FaceLandmarker.create_from_options(options)


def get_landmarks_3d(detector, frame_rgb, timestamp_ms):
    """
    Run the FaceLandmarker on an RGB numpy frame.
    Returns an (468, 3) numpy array of (x, y, z) landmarks, or None if no face found.
    """
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)
    result = detector.detect_for_video(mp_image, timestamp_ms)

    if not result.face_landmarks:
        return None

    lm = result.face_landmarks[0]
    coords = np.array([[p.x, p.y, p.z] for p in lm], dtype=np.float32)
    return coords
