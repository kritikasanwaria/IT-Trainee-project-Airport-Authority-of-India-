"""
verify.py
---------
Captures the live face from the webcam and checks it against everyone
stored in face_data.pkl (created by enroll.py).

Matching logic:
  1. Compare 128-d face embedding (face_recognition) -> primary identity check
  2. Compare 3D landmark geometry (MediaPipe) -> secondary geometric check,
     helps reduce false accepts from photos/videos (basic liveness signal)

Usage:
    python verify.py
"""

import pickle
import os

import cv2
import numpy as np
import face_recognition

from face3d_utils import create_face_landmarker, get_landmarks_3d

DB_PATH = "face_data.pkl"
EMBEDDING_THRESHOLD = 0.5   # lower = stricter. face_recognition distance, typical range 0-1
LANDMARK_THRESHOLD = 0.06   # normalized landmark distance, tune experimentally


def load_db():
    if not os.path.exists(DB_PATH):
        print("No enrolled faces found. Run enroll.py first.")
        return {}
    with open(DB_PATH, "rb") as f:
        return pickle.load(f)


def normalize_landmarks(coords):
    """Center and scale landmarks so comparison is position/scale invariant."""
    centered = coords - coords.mean(axis=0)
    scale = np.linalg.norm(centered, axis=1).max()
    if scale == 0:
        return centered
    return centered / scale


def landmark_distance(a, b):
    a_n = normalize_landmarks(a)
    b_n = normalize_landmarks(b)
    return np.mean(np.linalg.norm(a_n - b_n, axis=1))


def main():
    db = load_db()
    if not db:
        return

    names = list(db.keys())
    known_embeddings = [db[n]["embedding"] for n in names]

    landmarker = create_face_landmarker()
    frame_timestamp_ms = 0

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: could not open webcam.")
        return

    print("Verifying... press 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb = np.ascontiguousarray(rgb)
        frame_timestamp_ms += 33  # approx frame interval, must be increasing

        face_locations = face_recognition.face_locations(rgb, model="hog")
        display = frame.copy()

        label = "No face detected"
        color = (0, 0, 255)

        if face_locations:
            top, right, bottom, left = face_locations[0]
            encodings = face_recognition.face_encodings(rgb, [face_locations[0]])
            landmarks_3d = get_landmarks_3d(landmarker, rgb, frame_timestamp_ms)

            if encodings:
                live_embedding = encodings[0]
                distances = face_recognition.face_distance(known_embeddings, live_embedding)
                best_idx = int(np.argmin(distances))
                best_distance = distances[best_idx]
                best_name = names[best_idx]

                if best_distance < EMBEDDING_THRESHOLD:
                    # Secondary geometric check
                    geom_ok = True
                    geom_dist = None
                    if landmarks_3d is not None:
                        stored_landmarks = db[best_name]["landmarks_3d"]
                        geom_dist = landmark_distance(landmarks_3d, stored_landmarks)
                        geom_ok = geom_dist < LANDMARK_THRESHOLD

                    if geom_ok:
                        label = f"MATCH: {best_name} (dist={best_distance:.3f})"
                        color = (0, 255, 0)
                    else:
                        label = f"Embedding matched '{best_name}' but geometry check failed"
                        color = (0, 165, 255)
                else:
                    label = f"Unknown face (closest: {best_name}, dist={best_distance:.3f})"
                    color = (0, 0, 255)

            cv2.rectangle(display, (left, top), (right, bottom), color, 2)

        cv2.putText(display, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        cv2.imshow("Verification - press q to quit", display)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    landmarker.close()


if __name__ == "__main__":
    main()
