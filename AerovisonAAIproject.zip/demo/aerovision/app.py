import os
import sys
import subprocess
import uuid
import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from database import (
    init_db, get_user_by_email, get_admin_by_email,
    get_user_by_id, get_admin_by_id,
    get_flights_for_user, get_history_for_user,
    get_all_users, get_all_history, create_user,
    search_users, count_users
)

from face_integration import enroll_face_for_user, verify_face_at_gate


# Make Face/ importable and runnable when app is launched from aerovision/

FACE_DIR = os.path.join(os.path.dirname(__file__), '..', 'Face')
FACE_DIR = os.path.abspath(FACE_DIR)
if FACE_DIR not in sys.path:
    sys.path.insert(0, FACE_DIR)


app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = os.environ.get('SESSION_SECRET', 'aerovision-secret-key-2024')

with app.app_context():
    init_db()


# ── Auth helpers ─────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session and 'admin_id' not in session:
            flash('Please log in to continue.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def user_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in as a user to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Admin access required.', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated


def current_user():
    if 'user_id' in session:
        row = get_user_by_id(session['user_id'])
        if row:
            return dict(row)
    return None


def current_admin():
    if 'admin_id' in session:
        row = get_admin_by_id(session['admin_id'])
        if row:
            return dict(row)
    return None


CHAT_HISTORY = [
    {'sender': 'bot', 'message': 'Hello! How can I assist you today?'},
    {'sender': 'user', 'message': 'How does face recognition work?'},
    {'sender': 'bot', 'message': 'Face recognition uses AI to map your facial features and match them with your registered data securely.'},
]

SUGGESTED_QUESTIONS = ['Boarding Process', 'My Bookings', 'Face Enrollment', 'FAQs']


# ── Public routes ─────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html', user=current_user())


# ── User Auth ─────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user = get_user_by_email(email)
        if user and check_password_hash(user['password_hash'], password):
            if user['status'] == 'Suspended':
                flash('Your account has been suspended. Please contact support.', 'error')
                return render_template('login.html')
            session['user_id'] = user['id']
            session['role'] = 'user'
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password.', 'error')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        if not (name and email and password):
            flash('Please fill all fields.', 'error')
            return render_template('login.html', register=True)
        user = create_user(name, email, generate_password_hash(password))
        if user is None:
            flash('An account with this email already exists.', 'error')
            return render_template('login.html', register=True)
        session['user_id'] = user['id']
        session['role'] = 'user'
        flash('Account created successfully! Welcome aboard.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('login.html', register=True)


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


# ── Admin Auth ────────────────────────────────────────────────────────────────

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if 'admin_id' in session:
        return redirect(url_for('admin'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        admin = get_admin_by_email(email)
        if admin and check_password_hash(admin['password_hash'], password):
            session['admin_id'] = admin['id']
            session['role'] = 'admin'
            flash(f'Welcome, {admin["name"]}! Admin access granted.', 'success')
            return redirect(url_for('admin'))
        else:
            flash('Invalid admin credentials.', 'error')
    return render_template('admin_login.html')


@app.route('/admin-logout')
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))


# ── User Dashboard routes ─────────────────────────────────────────────────────

@app.route('/dashboard')
@user_required
def dashboard():
    user = current_user()
    flights = [dict(f) for f in get_flights_for_user(user['id'])]
    history = [dict(h) for h in get_history_for_user(user['id'], limit=3)]
    return render_template('dashboard.html', user=user, flights=flights, history=history)


@app.route('/enrollment')
@user_required
def enrollment():
    return render_template('enrollment.html', user=current_user())


@app.route('/enrollment/enroll-face', methods=['POST'])
@user_required
def enrollment_enroll_face():
    user = current_user()
    # Run webcam enrollment on the server
    result = enroll_face_for_user(user_id=user['id'], user_display_name=user['name'])

    if result['ok']:
        # Update DB flags
        # (Simple approach: direct SQL update since db.py has no helper)
        conn = __import__('database').get_db()
        conn.execute('UPDATE users SET face_enrolled = 1, face_verified = face_verified WHERE id = ?', (user['id'],))
        conn.commit()
        conn.close()
        flash('Face enrollment successful!', 'success')
    else:
        flash('Face enrollment failed. See server logs/output.', 'error')

    return redirect(url_for('enrollment'))



@app.route('/bookings')
@user_required
def bookings():
    user = current_user()
    flights = [dict(f) for f in get_flights_for_user(user['id'])]
    return render_template('bookings.html', user=user, flights=flights)


@app.route('/boarding-pass')
@user_required
def boarding_pass():
    user = current_user()
    flight_id = request.args.get('flight', '')
    flights = [dict(f) for f in get_flights_for_user(user['id'])]
    flight = next((f for f in flights if f['flight_id'] == flight_id), flights[0] if flights else {})
    return render_template('boarding_pass.html', user=user, flight=flight)


@app.route('/history')
@user_required
def history():
    user = current_user()
    hist = [dict(h) for h in get_history_for_user(user['id'])]
    return render_template('history.html', user=user, history=hist)


@app.route('/chatbot', methods=['GET', 'POST'])
@user_required
def chatbot():
    user = current_user()
    chat = list(CHAT_HISTORY)
    if request.method == 'POST':
        msg = request.form.get('message', '').strip()
        if msg:
            chat.append({'sender': 'user', 'message': msg})
            chat.append({'sender': 'bot', 'message': _bot_reply(msg)})
    return render_template('chatbot.html', user=user, chat=chat, suggestions=SUGGESTED_QUESTIONS)


@app.route('/settings', methods=['GET', 'POST'])
@user_required
def settings():
    if request.method == 'POST':
        flash('Settings saved successfully!', 'success')
        return redirect(url_for('settings'))
    return render_template('settings.html', user=current_user())


# ── Admin Dashboard routes ────────────────────────────────────────────────────

@app.route('/admin')
@admin_required
def admin():
    admin = current_admin()
    stats = {
        'total_users': count_users(),
        'verifications_today': 8642,
        'success_rate': '98.6%',
        'active_flights': 128
    }
    history = [dict(h) for h in get_all_history(limit=5)]
    return render_template('admin.html', user=admin, stats=stats, history=history)


@app.route('/admin/users')
@admin_required
def admin_users():
    search = request.args.get('search', '')
    role = request.args.get('role', '')
    status = request.args.get('status', '')
    users = [dict(u) for u in search_users(search, role, status)]
    return render_template('users.html', user=current_admin(), users=users, search=search)


@app.route('/admin/verification')
@admin_required
def verification():
    admin = current_admin()
    all_hist = [dict(h) for h in get_all_history()]
    first_flight = {'id': 'AI204', 'origin': 'JFK', 'origin_city': 'New York',
                    'destination': 'LHR', 'destination_city': 'London',
                    'date': '24 May 2025', 'boarding_time': '10:30 AM',
                    'terminal': '3', 'gate': 'Gate 12', 'seat': '12A',
                    'class': 'Economy', 'status': 'On Time'}
    demo_user = {'name': 'John Doe', 'role': 'Premium Traveler',
                 'email': 'john.doe@email.com', 'face_enrolled': True, 'face_verified': True}

    # Use DB-backed latest verification if available, otherwise show demo.
    return render_template('verification.html', user=admin, flight=first_flight,
                           passenger=demo_user, history=all_hist[:5])


@app.route('/admin/verification/scan-face', methods=['POST'])
@admin_required
def admin_verification_scan_face():
    admin = current_admin()
    result = verify_face_at_gate(timeout_sec=45)

    conn = __import__('database').get_db()
    if result['ok'] and result['matched_name']:
        # matched_name is like user_{id}
        face_key = result['matched_name']
        user_id = None
        if face_key.startswith('user_'):
            try:
                user_id = int(face_key.split('user_', 1)[1])
            except Exception:
                user_id = None

        if user_id is not None:
            # Update users table
            conn.execute('UPDATE users SET face_verified = 1, last_verified = CURRENT_TIMESTAMP WHERE id = ?', (user_id,))
            # Insert verification history
            now = datetime.datetime.utcnow()
            date_str = now.strftime('%d %b, %Y')
            time_str = now.strftime('%I:%M %p')
            conn.execute(
                'INSERT INTO verification_history (user_id, date, time, location, type, confidence, status) VALUES (?,?,?,?,?,?,?)',
                (
                    user_id,
                    date_str,
                    time_str,
                    'Terminal Gate 12',
                    'Boarding',
                    f"{(1 - (result['distance'] or 0)) * 100:.1f}%" if result['distance'] is not None else None,
                    'Success',
                )
            )
            conn.commit()
            conn.close()
            flash('Identity verified. Passenger approved.', 'success')
        else:
            conn.close()
            flash('Face matched but user mapping failed.', 'error')
    else:
        conn.close()
        flash('No valid match found. Passenger denied.', 'error')

    return redirect(url_for('verification'))



@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    if request.method == 'POST':
        flash('Admin settings saved!', 'success')
        return redirect(url_for('admin_settings'))
    return render_template('settings.html', user=current_admin())


# ── Helpers ───────────────────────────────────────────────────────────────────

def _bot_reply(msg):
    m = msg.lower()
    if 'boarding' in m:
        return 'The boarding process at AEROVISION is fully contactless. Simply approach the gate scanner, look at the camera, and your face will be verified in under 2 seconds!'
    elif 'book' in m or 'flight' in m:
        return 'You can view all your upcoming and past bookings in the My Bookings section.'
    elif 'enroll' in m or 'face' in m:
        return 'Face enrollment is quick! Go to the Face Enrollment page and follow the on-screen instructions.'
    elif 'faq' in m or 'help' in m:
        return 'I can help with boarding, bookings, face enrollment, and security FAQs. What would you like to know?'
    return f'Thank you for your question about "{msg}". Our AEROVISION system uses advanced AI for secure contactless boarding.'


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
