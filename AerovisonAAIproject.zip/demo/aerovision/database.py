import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), 'aerovision.db')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'Traveler',
            face_enrolled INTEGER DEFAULT 0,
            face_verified INTEGER DEFAULT 0,
            last_verified TEXT DEFAULT NULL,
            status TEXT DEFAULT 'Active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS flights (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flight_id TEXT NOT NULL,
            user_id INTEGER,
            origin TEXT,
            origin_city TEXT,
            destination TEXT,
            destination_city TEXT,
            date TEXT,
            boarding_time TEXT,
            departure TEXT,
            arrival TEXT,
            terminal TEXT,
            gate TEXT,
            seat TEXT,
            class TEXT,
            status TEXT DEFAULT 'Scheduled',
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS verification_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            date TEXT,
            time TEXT,
            location TEXT,
            type TEXT,
            confidence TEXT,
            status TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
    ''')

    cur.execute('SELECT COUNT(*) FROM users')
    if cur.fetchone()[0] == 0:
        _seed_data(cur)

    conn.commit()
    conn.close()


def _seed_data(cur):
    users = [
        ('John Doe', 'john.doe@email.com', generate_password_hash('password'), 'Premium Traveler', 1, 1, 'Today, 09:42 AM', 'Active'),
        ('Sarah Kim', 'sarah.kim@email.com', generate_password_hash('password'), 'Traveler', 1, 0, None, 'Active'),
        ('Michael Brown', 'michael@email.com', generate_password_hash('password'), 'Traveler', 0, 0, None, 'Suspended'),
        ('Jessica White', 'jessica@email.com', generate_password_hash('password'), 'Traveler', 1, 1, '23 May, 2025', 'Active'),
        ('David Lee', 'david@email.com', generate_password_hash('password'), 'Traveler', 1, 0, None, 'Active'),
        ('James Taylor', 'james@email.com', generate_password_hash('password'), 'Traveler', 0, 0, None, 'Active'),
    ]
    cur.executemany(
        'INSERT INTO users (name, email, password_hash, role, face_enrolled, face_verified, last_verified, status) VALUES (?,?,?,?,?,?,?,?)',
        users
    )

    admins = [
        ('Admin User', 'admin@aerovision.com', generate_password_hash('admin123')),
        ('Jessica White', 'jessica.admin@aerovision.com', generate_password_hash('admin123')),
    ]
    cur.executemany(
        'INSERT INTO admins (name, email, password_hash) VALUES (?,?,?)',
        admins
    )

    flights_data = [
        (1, 'AI204', 'JFK', 'New York', 'LHR', 'London', '24 May 2025', '10:30 AM', '10:30 AM', '10:30 PM', '3', 'Gate 12', '12A', 'Economy', 'On Time'),
        (1, 'AI301', 'LHR', 'London', 'DXB', 'Dubai', '10 Jun 2025', '08:00 AM', '08:00 AM', '06:00 PM', '5', 'Gate 8', '5C', 'Business', 'Scheduled'),
        (1, 'AI512', 'DXB', 'Dubai', 'SIN', 'Singapore', '20 Jun 2025', '11:15 PM', '11:15 PM', '09:30 AM', '1', 'Gate 22', '14B', 'Economy', 'Scheduled'),
    ]
    cur.executemany(
        'INSERT INTO flights (user_id, flight_id, origin, origin_city, destination, destination_city, date, boarding_time, departure, arrival, terminal, gate, seat, class, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        flights_data
    )

    history_data = [
        (1, '24 May, 2025', '09:42 AM', 'Terminal 3, Gate 12', 'Boarding', '98%', 'Success'),
        (1, '20 May, 2025', '03:15 PM', 'Terminal 3, Gate 5', 'Login', '96%', 'Success'),
        (1, '18 May, 2025', '11:32 AM', 'Online', 'Check-in', '91%', 'Success'),
        (1, '15 May, 2025', '08:20 AM', 'Terminal 1, Gate 7', 'Boarding', '94%', 'Success'),
        (1, '10 May, 2025', '10:05 AM', 'Online', 'Login', '89%', 'Failed'),
    ]
    cur.executemany(
        'INSERT INTO verification_history (user_id, date, time, location, type, confidence, status) VALUES (?,?,?,?,?,?,?)',
        history_data
    )


def get_user_by_email(email):
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
    conn.close()
    return user


def get_admin_by_email(email):
    conn = get_db()
    admin = conn.execute('SELECT * FROM admins WHERE email = ?', (email,)).fetchone()
    conn.close()
    return admin


def get_user_by_id(user_id):
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    return user


def get_admin_by_id(admin_id):
    conn = get_db()
    admin = conn.execute('SELECT * FROM admins WHERE id = ?', (admin_id,)).fetchone()
    conn.close()
    return admin


def get_flights_for_user(user_id):
    conn = get_db()
    flights = conn.execute('SELECT * FROM flights WHERE user_id = ?', (user_id,)).fetchall()
    conn.close()
    return flights


def get_history_for_user(user_id, limit=None):
    conn = get_db()
    if limit:
        rows = conn.execute(
            'SELECT * FROM verification_history WHERE user_id = ? ORDER BY id DESC LIMIT ?',
            (user_id, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            'SELECT * FROM verification_history WHERE user_id = ? ORDER BY id DESC',
            (user_id,)
        ).fetchall()
    conn.close()
    return rows


def get_all_users():
    conn = get_db()
    users = conn.execute('SELECT * FROM users ORDER BY id').fetchall()
    conn.close()
    return users


def get_all_history(limit=None):
    conn = get_db()
    if limit:
        rows = conn.execute(
            'SELECT vh.*, u.name FROM verification_history vh LEFT JOIN users u ON vh.user_id = u.id ORDER BY vh.id DESC LIMIT ?',
            (limit,)
        ).fetchall()
    else:
        rows = conn.execute(
            'SELECT vh.*, u.name FROM verification_history vh LEFT JOIN users u ON vh.user_id = u.id ORDER BY vh.id DESC'
        ).fetchall()
    conn.close()
    return rows


def create_user(name, email, password_hash):
    conn = get_db()
    try:
        conn.execute(
            'INSERT INTO users (name, email, password_hash) VALUES (?,?,?)',
            (name, email, password_hash)
        )
        conn.commit()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        return user
    except sqlite3.IntegrityError:
        conn.close()
        return None


def search_users(query='', role='', status=''):
    conn = get_db()
    sql = 'SELECT * FROM users WHERE 1=1'
    params = []
    if query:
        sql += ' AND (name LIKE ? OR email LIKE ?)'
        params += [f'%{query}%', f'%{query}%']
    if role:
        sql += ' AND role = ?'
        params.append(role)
    if status:
        sql += ' AND status = ?'
        params.append(status)
    users = conn.execute(sql, params).fetchall()
    conn.close()
    return users


def count_users():
    conn = get_db()
    n = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    conn.close()
    return n
