import os
import subprocess
import sys
import uuid
import datetime
from typing import Optional, Tuple, Dict, Any


APP_DIR = os.path.dirname(__file__)
DEMO_ROOT = os.path.abspath(os.path.join(APP_DIR, '..'))
FACE_DIR = os.path.join(DEMO_ROOT, 'Face')
ENROLL_PY = os.path.join(FACE_DIR, 'enroll.py')
VERIFY_PY = os.path.join(FACE_DIR, 'verify.py')


def _run_script(script_path: str, args: list, timeout_sec: int = 90) -> Tuple[int, str]:
    """Run a python script as a subprocess.

    Returns (exit_code, stdout+stderr).
    """
    py_exe = sys.executable
    cmd = [py_exe, script_path] + args

    env = os.environ.copy()
    # Ensure scripts can import Face/ modules
    env['PYTHONPATH'] = os.pathsep.join([FACE_DIR, env.get('PYTHONPATH', '')])

    proc = subprocess.run(
        cmd,
        cwd=FACE_DIR,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=timeout_sec,
    )
    return proc.returncode, proc.stdout


def enroll_face_for_user(user_id: int, user_display_name: str, timeout_sec: int = 120) -> Dict[str, Any]:
    """Enroll a user's face by running Face/enroll.py.

    Note: enroll.py stores embeddings in Face/face_data.pkl keyed by --name.
    We map that name to a unique user identifier to support multi-user.
    """
    face_key = f'user_{user_id}'
    exit_code, output = _run_script(
        ENROLL_PY,
        ['--name', face_key],
        timeout_sec=timeout_sec,
    )

    ok = exit_code == 0
    return {
        'ok': ok,
        'exit_code': exit_code,
        'output': output,
        'face_key': face_key,
        'enrolled_at': datetime.datetime.utcnow().isoformat() + 'Z' if ok else None,
    }


def verify_face_at_gate(timeout_sec: int = 60) -> Dict[str, Any]:
    """Run Face/verify.py and attempt to parse the best match from its output.

    Since verify.py is interactive (press q to quit) and currently does not provide
    an automatic one-shot verification, we rely on a short timeout.

    Returns:
      - ok: True if we detected a MATCH line
      - matched_name: best_name parsed from MATCH output
      - distance: parsed embedding distance if present
      - raw_output: full stdout
    """
    exit_code, output = _run_script(
        VERIFY_PY,
        [],
        timeout_sec=timeout_sec,
    )

    matched_name: Optional[str] = None
    distance: Optional[float] = None

    # Expected line in verify.py: MATCH: {best_name} (dist={best_distance:.3f})
    for line in output.splitlines():
        if line.startswith('MATCH:'):
            # remove leading MATCH:
            # Example: MATCH: user_12 (dist=0.321)
            try:
                rest = line[len('MATCH:'):].strip()
                # rest: user_12 (dist=0.321)
                if '(' in rest:
                    name_part, dist_part = rest.split('(', 1)
                    matched_name = name_part.strip()
                    if 'dist=' in dist_part:
                        dist_str = dist_part.split('dist=', 1)[1]
                        dist_str = dist_str.replace(')', '').strip()
                        distance = float(dist_str)
            except Exception:
                pass
            break

    ok = matched_name is not None
    return {
        'ok': ok,
        'exit_code': exit_code,
        'matched_name': matched_name,
        'distance': distance,
        'raw_output': output,
        'verified_at': datetime.datetime.utcnow().isoformat() + 'Z' if ok else None,
    }

