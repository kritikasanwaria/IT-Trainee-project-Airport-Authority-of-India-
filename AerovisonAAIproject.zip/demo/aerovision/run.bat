@echo off
echo Installing dependencies...
pip install -r requirements.txt
echo.
echo Starting AEROVISION...
echo Open http://localhost:5000 in your browser
echo.
echo User login:  john.doe@email.com / password
echo Admin login: admin@aerovision.com / admin123
echo.
python app.py
pause
